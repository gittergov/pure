
export DB_HOST_SRC=oracle1
export DB_HOST_TGT=oracle2

export DB_HOST_USER_SRC=oracle
export DB_HOST_USER_TGT=oracle

export ASM_HOST_USER_SRC=grid
export ASM_HOST_USER_TGT=grid

export DB_HOST_PASS_SRC=Password1!
export DB_HOST_PASS_TGT=Password1!

#export DB_PORT_SRC=1521
#export DB_PORT_TGT=1521

export DB_USER_SRC=system
export DB_USER_TGT=system

export DB_PASS_SRC=manager
export DB_PASS_TGT=manager


export FLASH_ARRAY=fa-1.testdrive.local
export FA_USER=pureuser
export FA_PASS=pureuser

export PG_NAME_SRC=Oracle1-PG
export PG_NAME_TGT=Oracle2-PG

