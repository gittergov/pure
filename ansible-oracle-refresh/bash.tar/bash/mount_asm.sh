#!/bin/bash

. ./env_grid.sh

sqlplus -s / as sysasm @mount_asm.sql

